# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.dao', 'src.models', 'src.tests']

package_data = \
{'': ['*'], 'src.tests': ['.pytest_cache/*']}

install_requires = \
['flask>=2.2.2,<3.0.0', 'httpx>=0.23.1,<0.24.0']

setup_kwargs = {
    'name': 'firstserver',
    'version': '0.1.0',
    'description': 'Servidor criado com flask para estudos py.',
    'long_description': '',
    'author': 'Johnnick F. Landim',
    'author_email': 'johnnick.landim@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
